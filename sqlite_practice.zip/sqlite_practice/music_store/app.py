from flask import Flask, render_template, request, redirect
import sqlite3
import random
from datetime import date

app = Flask(__name__)

# -----------------------------------
#  🔌 Дерекқорға қосылу
# -----------------------------------
def get_db_connection():
    con = sqlite3.connect("music_store.db")
    con.row_factory = sqlite3.Row
    return con


# -----------------------------------
#  🏠 Басты бет
# -----------------------------------
@app.route("/")
def index():
    return render_template("index.html")


# -----------------------------------
#  👤 Қолданушы бөлімі (дүкен)
# -----------------------------------
@app.route("/user")
def user_shop():
    con = get_db_connection()
    turler = con.execute("SELECT * FROM AspapTuri").fetchall()

    search = request.args.get("search", "")
    turi = request.args.get("turi", "")
    sort = request.args.get("sort", "")

    query = """
        SELECT a.idType, a.atauy, a.bagasy, a.shygarilgan_zheri,
               o.atauy AS ondirushi, t.aspap_turi
        FROM Aspap a
        JOIN Ondirushi o ON a.idOndirushi = o.idOndirushi
        JOIN AspapTuri t ON a.idAspap = t.idAspap
        WHERE a.atauy LIKE ?
    """
    params = [f"%{search}%"]

    if turi:
        query += " AND a.idAspap = ?"
        params.append(turi)

    if sort == "asc":
        query += " ORDER BY a.bagasy ASC"
    elif sort == "desc":
        query += " ORDER BY a.bagasy DESC"

    aspaplar = con.execute(query, params).fetchall()
    con.close()

    return render_template("user/shop.html", aspaplar=aspaplar, turler=turler)


# -----------------------------------
#  🛒 Сатып алу
# -----------------------------------
@app.route("/buy", methods=["GET", "POST"])
def buy():
    if request.method == "POST":
        idType = request.form["idType"]
        aty = request.form["aty"]
        mekenzhai = request.form["mekenzhai"]
        telefon = request.form["telefon"]
        sany = int(request.form["sany"])
        kuni = date.today().strftime("%Y-%m-%d")

        con = get_db_connection()

        # Клиентті жазу
        con.execute("""
            INSERT OR IGNORE INTO Klient (aty, mekenzhai, telefon)
            VALUES (?, ?, ?)
        """, (aty, mekenzhai, telefon))

        # Баға және жалпы сома
        bagasy = con.execute("SELECT bagasy FROM Aspap WHERE idType = ?", (idType,)).fetchone()["bagasy"]
        jalpy = bagasy * sany

        # 🔹 Рандом қызметкер таңдау
        kyz_list = [row["idKyzmetker"] for row in con.execute("SELECT idKyzmetker FROM Kyzmetker").fetchall()]
        rand_id = random.choice(kyz_list) if kyz_list else 1

        # Сатылымды жазу
        con.execute("""
            INSERT INTO Satylum (idType, klient_aty, mekenzhai, sany, kuni, jalpy_baga, idKyzmetker)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (idType, aty, mekenzhai, sany, kuni, jalpy, rand_id))

        con.commit()
        con.close()
        return redirect("/user")

    idType = request.args.get("idType")
    return render_template("user/buy.html", idType=idType)


# -----------------------------------
#  👨‍💼 Әкімші панелі (басқару)
# -----------------------------------
@app.route("/admin")
def admin_dashboard():
    return render_template("admin/dashboard.html")


# -----------------------------------
#  🎸 Аспаптар тізімі
# -----------------------------------
@app.route("/admin/aspap")
def admin_aspap_list():
    con = get_db_connection()
    aspaplar = con.execute("""
        SELECT a.idType, a.atauy, a.bagasy, a.shygarilgan_zheri,
               o.atauy AS ondirushi, t.aspap_turi
        FROM Aspap a
        JOIN Ondirushi o ON a.idOndirushi = o.idOndirushi
        JOIN AspapTuri t ON a.idAspap = t.idAspap
    """).fetchall()
    con.close()
    return render_template("admin/aspap_list.html", aspaplar=aspaplar)


# ➕ Аспап қосу
@app.route("/admin/aspap/add", methods=["GET", "POST"])
def admin_aspap_add():
    con = get_db_connection()
    turler = con.execute("SELECT * FROM AspapTuri").fetchall()
    ondirushiler = con.execute("SELECT * FROM Ondirushi").fetchall()

    if request.method == "POST":
        ata = request.form["atauy"]
        bagasy = int(request.form["bagasy"])
        shygar = request.form.get("shygarilgan_zheri", "")
        idAspap = int(request.form["idAspap"])
        idOnd = int(request.form["idOndirushi"])

        con.execute("""
            INSERT INTO Aspap (idAspap, atauy, bagasy, shygarilgan_zheri, idOndirushi)
            VALUES (?, ?, ?, ?, ?)
        """, (idAspap, ata, bagasy, shygar, idOnd))
        con.commit()
        con.close()
        return redirect("/admin/aspap")

    con.close()
    return render_template("admin/aspap_form.html", title="➕ Аспап қосу",
                           item=None, turler=turler, ondirushiler=ondirushiler)


# ✏️ Аспап өзгерту
@app.route("/admin/aspap/edit/<int:idType>", methods=["GET", "POST"])
def admin_aspap_edit(idType):
    con = get_db_connection()
    turler = con.execute("SELECT * FROM AspapTuri").fetchall()
    ondirushiler = con.execute("SELECT * FROM Ondirushi").fetchall()
    item = con.execute("SELECT * FROM Aspap WHERE idType=?", (idType,)).fetchone()

    if not item:
        con.close()
        return redirect("/admin/aspap")

    if request.method == "POST":
        ata = request.form["atauy"]
        bagasy = int(request.form["bagasy"])
        shygar = request.form.get("shygarilgan_zheri", "")
        idAspap = int(request.form["idAspap"])
        idOnd = int(request.form["idOndirushi"])
        con.execute("""
            UPDATE Aspap
               SET idAspap=?, atauy=?, bagasy=?, shygarilgan_zheri=?, idOndirushi=?
             WHERE idType=?
        """, (idAspap, ata, bagasy, shygar, idOnd, idType))
        con.commit()
        con.close()
        return redirect("/admin/aspap")

    con.close()
    return render_template("admin/aspap_form.html", title="✏️ Аспапты өзгерту",
                           item=item, turler=turler, ondirushiler=ondirushiler)


# ❌ Аспап жою
@app.route("/admin/aspap/delete/<int:idType>")
def admin_aspap_delete(idType):
    con = get_db_connection()
    con.execute("DELETE FROM Aspap WHERE idType = ?", (idType,))
    con.commit()
    con.close()
    return redirect("/admin/aspap")


# -----------------------------------
#  💰 Сатылымдар
# -----------------------------------
@app.route("/admin/sales")
def admin_sales():
    con = get_db_connection()
    sales = con.execute("""
        SELECT s.idSatylum, s.klient_aty, s.mekenzhai, s.sany, s.kuni,
               s.jalpy_baga, k.aty AS kyzmetker, a.atauy
        FROM Satylum s
        JOIN Kyzmetker k ON s.idKyzmetker = k.idKyzmetker
        JOIN Aspap a ON s.idType = a.idType
    """).fetchall()
    con.close()
    return render_template("admin/sales.html", sales=sales)


# -----------------------------------
#  👥 Клиенттер
# -----------------------------------
@app.route("/admin/clients")
def admin_clients():
    con = get_db_connection()
    clients = con.execute("SELECT * FROM Klient").fetchall()
    con.close()
    return render_template("admin/clients.html", clients=clients)


# -----------------------------------
#  👨‍💼 Қызметкерлер
# -----------------------------------
@app.route("/admin/employees")
def admin_employees():
    con = get_db_connection()
    employees = con.execute("SELECT * FROM Kyzmetker").fetchall()
    con.close()
    return render_template("admin/employees.html", employees=employees)


# -----------------------------------
#  🏭 Өндірушілер (CRUD)
# -----------------------------------
@app.route("/admin/manufacturers")
def admin_manufacturers():
    con = get_db_connection()
    ondirushiler = con.execute("SELECT * FROM Ondirushi").fetchall()
    con.close()
    return render_template("admin/manufacturers.html", ondirushiler=ondirushiler)


@app.route("/admin/manufacturers/add", methods=["GET", "POST"])
def admin_manufacturer_add():
    if request.method == "POST":
        atauy = request.form["atauy"]
        el = request.form["el"]
        con = get_db_connection()
        con.execute("INSERT INTO Ondirushi (atauy, el) VALUES (?, ?)", (atauy, el))
        con.commit()
        con.close()
        return redirect("/admin/manufacturers")
    return render_template("admin/manufacturer_form.html", title="➕ Өндіруші қосу", item=None)


@app.route("/admin/manufacturers/edit/<int:id>", methods=["GET", "POST"])
def admin_manufacturer_edit(id):
    con = get_db_connection()
    item = con.execute("SELECT * FROM Ondirushi WHERE idOndirushi=?", (id,)).fetchone()
    if not item:
        con.close()
        return redirect("/admin/manufacturers")

    if request.method == "POST":
        atauy = request.form["atauy"]
        el = request.form["el"]
        con.execute("UPDATE Ondirushi SET atauy=?, el=? WHERE idOndirushi=?", (atauy, el, id))
        con.commit()
        con.close()
        return redirect("/admin/manufacturers")

    con.close()
    return render_template("admin/manufacturer_form.html", title="✏️ Өндірушіні өзгерту", item=item)


@app.route("/admin/manufacturers/delete/<int:id>")
def admin_manufacturer_delete(id):
    con = get_db_connection()
    con.execute("DELETE FROM Ondirushi WHERE idOndirushi=?", (id,))
    con.commit()
    con.close()
    return redirect("/admin/manufacturers")


# -----------------------------------
#  🎶 Аспап түрлері (CRUD)
# -----------------------------------
@app.route("/admin/types")
def admin_types():
    con = get_db_connection()
    turler = con.execute("SELECT * FROM AspapTuri").fetchall()
    con.close()
    return render_template("admin/types.html", turler=turler)


@app.route("/admin/types/add", methods=["GET", "POST"])
def admin_type_add():
    if request.method == "POST":
        aspap_turi = request.form["aspap_turi"]
        con = get_db_connection()
        con.execute("INSERT INTO AspapTuri (aspap_turi) VALUES (?)", (aspap_turi,))
        con.commit()
        con.close()
        return redirect("/admin/types")
    return render_template("admin/type_form.html", title="➕ Түр қосу", item=None)


@app.route("/admin/types/edit/<int:id>", methods=["GET", "POST"])
def admin_type_edit(id):
    con = get_db_connection()
    item = con.execute("SELECT * FROM AspapTuri WHERE idAspap=?", (id,)).fetchone()
    if not item:
        con.close()
        return redirect("/admin/types")

    if request.method == "POST":
        aspap_turi = request.form["aspap_turi"]
        con.execute("UPDATE AspapTuri SET aspap_turi=? WHERE idAspap=?", (aspap_turi, id))
        con.commit()
        con.close()
        return redirect("/admin/types")

    con.close()
    return render_template("admin/type_form.html", title="✏️ Түрді өзгерту", item=item)


@app.route("/admin/types/delete/<int:id>")
def admin_type_delete(id):
    con = get_db_connection()
    con.execute("DELETE FROM AspapTuri WHERE idAspap=?", (id,))
    con.commit()
    con.close()
    return redirect("/admin/types")


# -----------------------------------
#  🚀 Іске қосу
# -----------------------------------
if __name__ == "__main__":
    app.run(debug=True)