import sqlite3

# ------------------------------------------
# 1. Создание базы и подключение
# ------------------------------------------
con = sqlite3.connect("music_store.db")
cur = con.cursor()

# ------------------------------------------
# 2. Очистка старых таблиц
# ------------------------------------------
cur.executescript("""
DROP TABLE IF EXISTS Satylum;
DROP TABLE IF EXISTS Aspap;
DROP TABLE IF EXISTS AspapTuri;
DROP TABLE IF EXISTS Ondirushi;
DROP TABLE IF EXISTS Klient;
DROP TABLE IF EXISTS Kyzmetker;
""")

# ------------------------------------------
# 3. Создание таблиц
# ------------------------------------------
cur.executescript("""
CREATE TABLE AspapTuri (
    idAspap INTEGER PRIMARY KEY AUTOINCREMENT,
    aspap_turi TEXT NOT NULL
);

CREATE TABLE Ondirushi (
    idOndirushi INTEGER PRIMARY KEY AUTOINCREMENT,
    atauy TEXT NOT NULL,
    el TEXT NOT NULL
);

CREATE TABLE Aspap (
    idType INTEGER PRIMARY KEY AUTOINCREMENT,
    idAspap INTEGER,
    atauy TEXT NOT NULL,
    bagasy INTEGER NOT NULL,
    shygarilgan_zheri TEXT,
    idOndirushi INTEGER,
    FOREIGN KEY(idAspap) REFERENCES AspapTuri(idAspap),
    FOREIGN KEY(idOndirushi) REFERENCES Ondirushi(idOndirushi)
);

CREATE TABLE Klient (
    idKlient INTEGER PRIMARY KEY AUTOINCREMENT,
    aty TEXT NOT NULL,
    mekenzhai TEXT,
    telefon TEXT
);

CREATE TABLE Kyzmetker (
    idKyzmetker INTEGER PRIMARY KEY AUTOINCREMENT,
    aty TEXT NOT NULL,
    lavazym TEXT
);

CREATE TABLE Satylum (
    idSatylum INTEGER PRIMARY KEY AUTOINCREMENT,
    idType INTEGER,
    klient_aty TEXT,
    mekenzhai TEXT,
    sany INTEGER,
    kuni DATE,
    jalpy_baga INTEGER,
    idKyzmetker INTEGER,
    FOREIGN KEY(idType) REFERENCES Aspap(idType),
    FOREIGN KEY(idKyzmetker) REFERENCES Kyzmetker(idKyzmetker)
);
""")

# ------------------------------------------
# 4. Добавление данных
# ------------------------------------------
cur.executemany("INSERT INTO AspapTuri (aspap_turi) VALUES (?)", [
    ("Ішекті",),
    ("Ұрмалы",),
    ("Үрмелі",),
    ("Клавишті",),
    ("Электронды",)
])

cur.executemany("INSERT INTO Ondirushi (atauy, el) VALUES (?, ?)", [
    ("Yamaha", "Жапония"),
    ("Fender", "АҚШ"),
    ("Roland", "Жапония"),
    ("Gibson", "АҚШ"),
    ("Korg", "Жапония")
])

cur.executemany("""
INSERT INTO Aspap (idAspap, atauy, bagasy, shygarilgan_zheri, idOndirushi)
VALUES (?, ?, ?, ?, ?)
""", [
    (1, "Акустикалық гитара", 120000, "Токио", 1),
    (1, "Электрогитара", 250000, "Киото", 2),
    (2, "Барабан жинағы", 400000, "Осака", 3),
    (3, "Саксофон", 300000, "Нью-Йорк", 4),
    (4, "Синтезатор", 350000, "Токио", 5),
    (5, "DJ контроллер", 200000, "Сеул", 3)
])

cur.executemany("INSERT INTO Klient (aty, mekenzhai, telefon) VALUES (?, ?, ?)", [
    ("Айбек", "Алматы", "87015551234"),
    ("Дана", "Астана", "87021234567"),
    ("Руслан", "Шымкент", "87037778899"),
    ("Аружан", "Қарағанды", "87041112233"),
    ("Ермек", "Қостанай", "87056667788")
])

cur.executemany("INSERT INTO Kyzmetker (aty, lavazym) VALUES (?, ?)", [
    ("Нұржан", "Менеджер"),
    ("Айгүл", "Сатушы"),
    ("Марат", "Консультант"),
    ("Жансая", "Сатушы"),
    ("Рустем", "Администратор")
])

cur.executemany("""
INSERT INTO Satylum (idType, klient_aty, mekenzhai, sany, kuni, jalpy_baga, idKyzmetker)
VALUES (?, ?, ?, ?, ?, ?, ?)
""", [
    (1, "Айбек", "Алматы", 1, "2025-01-15", 120000, 1),
    (2, "Дана", "Астана", 1, "2025-02-12", 250000, 2),
    (3, "Руслан", "Шымкент", 2, "2025-03-05", 800000, 3),
    (4, "Аружан", "Қарағанды", 1, "2025-04-10", 300000, 4),
    (5, "Ермек", "Қостанай", 1, "2025-05-25", 350000, 5),
    (6, "Айбек", "Алматы", 1, "2025-06-15", 200000, 1)
])

con.commit()

# ------------------------------------------
# 5. Примеры запросов с GROUP BY, UNION, ORDER BY
# ------------------------------------------

print("\n--- GROUP BY: Әр қызметкер бойынша сатылымдар сомасы ---")
for row in cur.execute("""
SELECT Kyzmetker.aty AS Kyzmetker, SUM(Satylum.jalpy_baga) AS JalpySatys
FROM Satylum
JOIN Kyzmetker ON Satylum.idKyzmetker = Kyzmetker.idKyzmetker
GROUP BY Kyzmetker.aty
ORDER BY JalpySatys DESC;
"""):
    print(row)

print("\n--- UNION: Барлық есімдердің тізімі (Клиенттер + Қызметкерлер) ---")
for row in cur.execute("""
SELECT aty FROM Klient
UNION
SELECT aty FROM Kyzmetker
ORDER BY aty;
"""):
    print(row)

print("\n--- ORDER BY: Баға бойынша құралдар (өсу реті) ---")
for row in cur.execute("""
SELECT atauy, bagasy FROM Aspap
ORDER BY bagasy ASC;
"""):
    print(row)


#  АГРЕГАТТЫҚ ФУНКЦИЯЛАР МЫСАЛДАРЫ


print("\n--- COUNT(): Барлық сатылым саны ---")
for row in cur.execute("""
SELECT COUNT(*) AS BarlykSatysSany
FROM Satylum;
"""):
    print(row)

print("\n--- SUM(): Барлық сатылым сомасы ---")
for row in cur.execute("""
SELECT SUM(jalpy_baga) AS BarlykSatysSomasy
FROM Satylum;
"""):
    print(row)

print("\n--- AVG(): Орташа сатылым бағасы ---")
for row in cur.execute("""
SELECT AVG(jalpy_baga) AS OrtashaBaga
FROM Satylum;
"""):
    print(row)

print("\n--- MIN(): Ең төмен баға ---")
for row in cur.execute("""
SELECT MIN(jalpy_baga) AS EnTomenBaga
FROM Satylum;
"""):
    print(row)

print("\n--- MAX(): Ең жоғары баға ---")
for row in cur.execute("""
SELECT MAX(jalpy_baga) AS EnJoğaryBaga
FROM Satylum;
"""):
    print(row)



con.close()
print("\n✅ База успешно создана и заполнена!")

